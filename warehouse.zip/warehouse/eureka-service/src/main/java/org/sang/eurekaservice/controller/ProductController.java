package org.sang.eurekaservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

@Controller
public class ProductController {
    @Value("${server.port}")
    private String port;
 /*   @RequestMapping("/user/hello")
    @ResponseBody
    public String hello(){
        System.out.println("进入接口调用");
        return "你好,"+port+"接口调用成功";
    }*/

}
