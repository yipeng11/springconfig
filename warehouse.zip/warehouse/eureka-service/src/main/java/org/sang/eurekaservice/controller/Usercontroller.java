package org.sang.eurekaservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Usercontroller {


    @GetMapping("/user/hello")
    public String hello() {
        System.out.println("接口调用成功！");
        return "index";
    }


}
