package org.sang.eurekaservice.service;


import org.sang.comment.entity.Warehouselisting;

import java.util.List;

public interface WarehouselistingService {
    List<Warehouselisting> listWarehouselisting();
    int addWarehouselisting(Warehouselisting warehouselisting);

}
