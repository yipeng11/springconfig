package org.sang.warehouse1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Warehouse1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
