package org.sang.warehouse1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Warehouse1Application {

    public static void main(String[] args) {
        SpringApplication.run(Warehouse1Application.class, args);
    }

}
