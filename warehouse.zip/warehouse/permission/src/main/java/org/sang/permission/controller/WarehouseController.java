package org.sang.permission.controller;/*
package org.sang.permission.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/warehouse")
public class WarehouseController {
    //入库管理
    @RequestMapping("/inwarehouse")
    public String inwarehouse() {
        return "inwarehouse";
    }

    //出库管理
    @RequestMapping("/outwarehouse")
    public String outwarehouse() {
        return "outwarehouse";
    }

    //移库管理
    @RequestMapping("/movemanagement")
    public String movemanagement() {
        return "movemanagement";
    }

}
*/
