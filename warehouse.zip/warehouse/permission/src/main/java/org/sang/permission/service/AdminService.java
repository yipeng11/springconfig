package org.sang.permission.service;


import org.sang.comment.entity.User;

import java.util.List;

public interface AdminService {
    int addAdmin(User user);//新增用户

    List<User> listUserInfo(User user);

    int deleteAdmin(int id);//删除用户

    User selectAdmin(int id);//查看用户信息

    int updateAdmin(User user);//修改用户
    int getCount();//查询总记录数

}
