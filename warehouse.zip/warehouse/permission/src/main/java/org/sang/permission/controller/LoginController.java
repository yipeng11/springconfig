package org.sang.permission.controller;

import org.sang.comment.entity.Department;
import org.sang.comment.entity.Permission;
import org.sang.comment.entity.User;
import org.sang.comment.entity.Warehouselisting;
import org.sang.permission.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
public class LoginController {
    @Autowired
    AdminServiceImpl adminService;
    @Autowired
    CharacterServiceImpl characterService;
    @Autowired
    DepartMentServiceImpl departMentService;
    @Autowired
    WarehouselistingServiceImpl warehouselistingService;
    @Autowired
    PermissionServiceImpl permissionService;

    @RequestMapping("/index")

    public String index() {
        System.out.println("进入首页");
        return "index";
    }

    @RequestMapping("/login")
    public String login() {
        System.out.println("进入登录页面");
        return "login";
    }

    //数据概览
    @RequestMapping("/dataview")
    public String dataview() {
        return "dataview";
    }

    //入库管理
    @RequestMapping("/inwarehouse")
    public String inwarehouse() {
        return "inwarehouse";
    }

    //出库管理
    @RequestMapping("/outwarehouse")
    public String outwarehouse() {
        return "outwarehouse";
    }

    //移库管理
    @RequestMapping("/movemanagement")
    public String movemanagement() {
        return "movemanagement";
    }

    //采购管理
    @RequestMapping("/purchasingmanagement")
    public String purchasingmanagement() {
        return "purchasingmanagement";
    }

    //采购退货
    @RequestMapping("/purchasereturn")
    public String purchasereturn() {
        return "purchasereturn";
    }

    //销售管理
    @RequestMapping("/salesmanagement")
    public String salesmanagement() {
        return "salesmanagement";
    }

    //销售退货
    @RequestMapping("/salesreturn")
    public String salesreturn() {
        return "salesreturn";
    }

    //新增销售订单
    @RequestMapping("/newsalesorders")
    public String newsalesorders() {
        return "newsalesorders";
    }


    //库存清单
    private static final String REST_URL_PREFIX = "http://EUREKA-CLIENT-USER-SERVICE";
    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/warehouselisting")
    public ModelAndView warehouselisting() {
        List<Warehouselisting> warehouselistingList = restTemplate.getForObject(REST_URL_PREFIX + "/warehouselisting11", List.class);
        ModelAndView mv = new ModelAndView();
        mv.addObject("warehouselistingList", warehouselistingList);
        mv.setViewName("warehouselisting2");
        return mv;
    }

 /*   @RequestMapping("/warehouselisting")
    public ModelAndView warehouselisting() {
        List<Warehouselisting> warehouselistingList = warehouselistingService.listWarehouselisting();
        ModelAndView mv = new ModelAndView();
        mv.addObject("warehouselistingList", warehouselistingList);
        mv.setViewName("warehouselisting2");
        return mv;
    }*/

    //可出库存
    @RequestMapping("/outinventory")
    public String outinventory() {
        return "outinventory";
    }

    //期初期末
    @RequestMapping("/beginningandending")
    public String beginningandending() {
        return "beginningandending";
    }

    //库存台账
    @RequestMapping("/warehousebill")
    public String warehousebill() {
        return "warehousebill";
    }

    //库存预警
    @RequestMapping("/warehousewarning")
    public String warehousewarning() {
        return "warehousewarning";
    }

    //库存容量
    @RequestMapping("/inventorycapacity")
    public String inventorycapacity() {
        return "inventorycapacity";
    }

    //调拨管理
    @RequestMapping("/staffmanagement")
    public String staffmanagement() {
        return "staffmanagement";
    }


    //员工管理
    @RequestMapping("/clientmanagement")
    public ModelAndView admins(User user, String pageNum) {

        if (pageNum == "" || pageNum == null) {
            pageNum = "0";
        }
        int count = adminService.getCount();
        int number = count % 2 == 0 ? count / 2 : count / 2 + 1;//总页数
        user.setPage(Integer.parseInt(pageNum) * 2);
        List<User> listUser = adminService.listUserInfo(user);
        ModelAndView mv = new ModelAndView();
        mv.addObject("listUser", listUser);
        mv.addObject("pageNum", pageNum);
        mv.addObject("number", number);
        mv.setViewName("clientmanagement2");
        return mv;
    }

    //角色管理
    @RequestMapping("/rolemanagement")
    public ModelAndView rolemanagement() {
        List<Character> characterList = characterService.characterList();
        ModelAndView mv = new ModelAndView();
        mv.addObject("characterList", characterList);
        mv.setViewName("rolemanagement2");
        return mv;
    }

    //删除角色用户
    @RequestMapping("/deleterolemanagement")
    public String deleterolemanagement(@RequestParam String id) {
        int result = characterService.deleteCharacter(Integer.parseInt(id));
        return "redirect:rolemanagement";
    }

    //跳转新增角色用户页面
    @RequestMapping("/addrolemanagement1")
    public String addrolemanagement1() {
        return "addrolemanagement";
    }

    //提交新增用户
    @RequestMapping("/addrolemanagement")
    public String addrolemanagement(Character character) {
        int result = characterService.addCharacter(character);
        return "redirect:rolemanagement";
    }

    //编辑角色用户页面
    @RequestMapping("/selectrolemanagement")
    public ModelAndView selectrolemanagement(@RequestParam String id) {
        Character character = characterService.selectCharacter(Integer.parseInt(id));
        ModelAndView mv = new ModelAndView();
        mv.addObject("character", character);
        mv.setViewName("editrolemanagement");
        return mv;
    }

    //修改用户
    @RequestMapping("/editrolemanagement")
    public String editrolemanagement(Character character) {
        int result = characterService.updateCharacter(character);
        System.out.println(result);

        return "redirect:rolemanagement";
    }

    //部门管理
    @RequestMapping("/divisionalmanagement")
    public ModelAndView divisionalmanagement() {
        List<Department> departmentList = departMentService.departmentList();
        ModelAndView mv = new ModelAndView();
        mv.addObject("departmentList", departmentList);
        mv.setViewName("divisionalmanagement2");
        return mv;

    }

    //删除部门
    @RequestMapping("/deletedivisionalmanagement")
    public String deletedivisionalmanagement(@RequestParam String id) {
        int result = departMentService.deleteDepartment(Integer.parseInt(id));
        return "redirect:divisionalmanagement";
    }

    //编辑部门管理页面
    @RequestMapping("/selectdivisionalmanagement")
    public ModelAndView selectdivisionalmanagement(@RequestParam String id) {
        Department department = departMentService.selectDepartment(Integer.parseInt(id));
        ModelAndView mv = new ModelAndView();
        mv.addObject("department", department);
        mv.setViewName("editdivisionalmanagement");
        return mv;
    }

    //修改部门
    @RequestMapping("/editdivisionalmanagement")
    public String editdivisionalmanagement(Department department) {
        int result = departMentService.updateDepartment(department);
        System.out.println(result);
        return "redirect:divisionalmanagement";
    }

    //跳转新增部门页面
    @RequestMapping("/adddivisionalmanagement1")
    public String adddivisionalmanagement1() {
        return "adddivisionalmanagement";
    }

    //新增部门
    @RequestMapping("/adddivisionalmanagement")
    public String adddivisionalmanagement(Department department) {
        int result = departMentService.addDepartment(department);
        return "redirect:divisionalmanagement";
    }

    /*    @RequestMapping("/permission")
        public ModelAndView permission(Permission permission) {
            List<Permission> list = permissionService.getPermission();
            User user = new User();
            user.setPage(-1);
            List<User> getAllUser = adminService.listUserInfo();
            ModelAndView mv = new ModelAndView();
            mv.addObject("permissions", list);
            mv.addObject("users", getAllUser);
            mv.setViewName("permission");
            return mv;
        }*/
//添加权限
    @RequestMapping("/addPermission")
    public void addPermission(int menuid[], int roleid, HttpServletResponse response) throws IOException, IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter writer = response.getWriter();
        int result = 0;
        if (menuid[0] != 0) {
            for (int i = 0; i < menuid.length; i++) {
                result += permissionService.addPermission(menuid[i], roleid);
            }
        }
        if (result == menuid.length) {
            writer.print("<script type='text/javascript'>");
            writer.print("alert( '赋权成功，跳转主页' );");
            writer.print("location.href=\"/clientmanagement\";");
            writer.print("</script>");
        } else {
            writer.print("<script type='text/javascript'>");
            writer.print("alert( '赋权失败，跳转主页' );");
            writer.print("location.href=\"/clientmanagement\";");
            writer.print("</script>");
        }
    }

    //权限分配
    @RequestMapping("permissionassignment")
    public ModelAndView permissionassignment() {
        User user = new User();
        user.setPage(-1);
        List<Permission> list = permissionService.getPermission();
        List<User> getAllUser = adminService.listUserInfo(user);
        ModelAndView mv = new ModelAndView();
        mv.addObject("permissions", list);
        mv.addObject("users", getAllUser);
        mv.setViewName("permission");
        return mv;


    }

    //资源管理
    @RequestMapping("/resourcemanagement")
    public String resourcemanagement() {
        return "resourcemanagement";
    }

    //新增入库
    @RequestMapping("/addinwarehouse")
    public String addinwarehouse() {
        return "addinwarehouse";
    }

    //编辑入库
    @RequestMapping("/editinwarehouse")
    public String editinwarehouse() {
        return "editinwarehouse";
    }

    //新增出库
    @RequestMapping("/addoutwarehouse")
    public String addoutwarehouse() {
        return "addoutwarehouse";
    }

    //编辑出库
    @RequestMapping("/editoutwarehouse")
    public String editoutwarehouse() {
        return "editoutwarehouse";
    }

    //新增移库
    @RequestMapping("/addmovemanagement")
    public String addmovemanagement() {
        return "addmovemanagement";
    }

    //编辑移库
    @RequestMapping("/editmovemanagement")
    public String editmovemanagement() {
        return "editmovemanagement";
    }

    //新增采购单
    @RequestMapping("/addpurchasingmanagement")
    public String addpurchasingmanagement() {
        return "addpurchasingmanagement";
    }

    //编辑采购单
    @RequestMapping("/editpurchasingmanagement")
    public String editpurchasingmanagement() {
        return "editpurchasingmanagement";
    }

    //编辑销售订单
    @RequestMapping("/editsalesmanagement")
    public String editsalesmanagement() {
        return "editsalesmanagement";
    }

    //挑转新增用户页面
    @RequestMapping("/addclientmanagement")
    public String addclientmanagement() {
        return "addclientmanagement2";
    }

    //提交新增用户
    @RequestMapping("/addclientmanagement1")
    public String addclientmanagement1(User user) {
        int result = adminService.addAdmin(user);
        return "redirect:clientmanagement";
    }

    //编辑用户
    @RequestMapping("/editclientmanagement")
    public ModelAndView editclientmanagement(@RequestParam String id) {
        User user = adminService.selectAdmin(Integer.parseInt(id));
        ModelAndView mv = new ModelAndView();
        mv.addObject("user", user);
        mv.setViewName("editclientmanagement2");
        return mv;
    }

    //修改用户
    @RequestMapping("/editclientmanagement1")
    public String editclientmanagement1(User user) {
        int result = adminService.updateAdmin(user);
        System.out.println(result);
        return "redirect:clientmanagement";
    }

    //删除用户
    @RequestMapping("/deleteclientmanagement")
    public String deleteclientmanagement(@RequestParam String id) {
        int result = adminService.deleteAdmin(Integer.parseInt(id));
        return "redirect:clientmanagement";
    }

/*    @Autowired
    RestTemplate restTemplate;*/

    @RequestMapping(value = "/admin", produces = "application/json;charset=UTF-8")
    public String adminInfo() {
        String abb = restTemplate.getForObject("http://localhost:8083/admin/getadminInfo", String.class);
        System.out.println(abb);
        return abb;
    }
}
