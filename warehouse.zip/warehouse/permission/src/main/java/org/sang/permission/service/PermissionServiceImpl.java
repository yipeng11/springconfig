package org.sang.permission.service;

import org.sang.comment.entity.Permission;
import org.sang.comment.mapper.PermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService {
    @Autowired
    PermissionMapper permissionMapper;
    @Override
    public List<Permission> getAllPermission() {
        return permissionMapper.getAllPermission();
    }

    @Override
    public List<Permission> getListPermission(Permission permission) {
        return permissionMapper.getListPermission(permission);
    }

    @Override
    public List<Permission> getPermission() {
        return permissionMapper.getPermission();
    }

    @Override
    public int addPermission(int menuid, int roleid) {
        return permissionMapper.addPermission(menuid,roleid);
    }

    @Override
    public int getCount() {
        return permissionMapper.getCount();
    }

    @Override
    public List<Permission> getDelPermission(int roleId) {
        return permissionMapper.getDelPermission(roleId);
    }

    @Override
    public int delPermission(int rmId) {
        return 0;
    }
}
