package org.sang.permission.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class UserController {
    private static final String REST_URL_PREFIX="http://eureka-client-user-service";
    @Autowired
    RestTemplate restTemplate;
    @GetMapping("/article/callHello")
    @ResponseBody
    public String hello(){
        System.out.println("开始调用接口");
        String str=restTemplate.getForObject(REST_URL_PREFIX+"/user/hello",String.class);
        System.out.println(str);
        return str;
    }
}
