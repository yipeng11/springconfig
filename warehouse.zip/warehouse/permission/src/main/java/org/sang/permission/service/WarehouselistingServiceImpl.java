package org.sang.permission.service;

import org.sang.comment.entity.Warehouselisting;
import org.sang.comment.mapper.WarehouselistingMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WarehouselistingServiceImpl implements WarehouselistingService {
    @Autowired
    WarehouselistingMapper warehouselistingMapper;


    public List<Warehouselisting> listWarehouselisting() {
        return warehouselistingMapper.listWarehouselisting();
    }

    @Override
    public int addWarehouselisting(Warehouselisting warehouselisting) {
        return warehouselistingMapper.addWarehouselisting(warehouselisting);
    }
}
