package org.sang.permission.service;

import org.sang.comment.entity.Department;
import org.sang.comment.mapper.DepartMentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartMentServiceImpl implements DepartMentService {
    @Autowired
    DepartMentMapper departMentMapper;

    @Override
    public List<Department> departmentList() {
        return departMentMapper.departmentList();
    }

    @Override
    public int addDepartment(Department department) {
        return departMentMapper.addDepartment(department);
    }

    @Override
    public int deleteDepartment(int id) {
        return departMentMapper.deleteDepartment(id);
    }

    @Override
    public Department selectDepartment(int id) {
        return departMentMapper.selectDepartment(id);
    }

    @Override
    public int updateDepartment(Department department) {
        return departMentMapper.updateDepartment(department);
    }
}
