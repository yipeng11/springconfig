package org.sang.permission.service;

import org.sang.comment.entity.User;
import org.sang.comment.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;

    @Override
    public int addAdmin(User user) {
        return adminMapper.addAdmin(user);
    }

    @Override
    public List<User> listUserInfo(User user) {
        return adminMapper.listUserInfo(user);
    }

    @Override
    public int deleteAdmin(int id) {
        return adminMapper.deleteAdmin(id);
    }

    @Override
    public User selectAdmin(int id) {
        return adminMapper.selectAdmin(id);
    }

    @Override
    public int updateAdmin(User user) {
        return adminMapper.updateAdmin(user);
    }

    @Override
    public int getCount() {
        return adminMapper.getCount();
    }
}
