package org.sang.permission;

import myrule.MyRules;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;

@MapperScan("org.sang.comment.mapper")
@SpringBootApplication
@EnableEurekaClient
@RibbonClient(name="EUREKA-CLIENT-USER-SERVICE",configuration = MyRules.class)
public class PermissionApplication {

    public static void main(String[] args) {
        SpringApplication.run(PermissionApplication.class, args);
    }

}
