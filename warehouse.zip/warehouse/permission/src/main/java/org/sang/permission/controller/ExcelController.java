package org.sang.permission.controller;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.sang.comment.entity.Warehouselisting;
import org.sang.permission.service.WarehouselistingServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/excel")
public class ExcelController {
    @Autowired
    WarehouselistingServiceImpl warehouselistingService;

    @RequestMapping("/downtemp")
    public void downtemp(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("进入下载模板");
        //创建一个工作簿Excel表格
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("用户资料模板.xls");
        //创建第一行数据,表格里面的标题
        HSSFRow headRow = sheet.createRow(0);
        //这是一些要导出列的标题
        String[] title = new String[]{"序号", "产品编号", "产品名称", "产品规格", "类别", "存储单位", "仓库", "库位"};
        for (int i = 0; i < title.length; i++) {
            headRow.createCell(i).setCellValue(title[i]);
        }
        List<Warehouselisting> warehouselistingList = warehouselistingService.listWarehouselisting();
        HSSFRow row = null;
        for (int i = 0; i < warehouselistingList.size(); i++) {
            row = sheet.createRow(i + 1);
            Warehouselisting warehouselisting = warehouselistingList.get(i);
            row.createCell(0).setCellValue(warehouselisting.getId());
            row.createCell(1).setCellValue(warehouselisting.getProductId());
            row.createCell(2).setCellValue(warehouselisting.getProductName());
            row.createCell(3).setCellValue(warehouselisting.getProductStandard());
            row.createCell(4).setCellValue(warehouselisting.getCategory());
            row.createCell(5).setCellValue(warehouselisting.getStorageCell());
            row.createCell(6).setCellValue(warehouselisting.getWarehouse());
            row.createCell(7).setCellValue(warehouselisting.getStorageLocation());
        }
        //要导出的数据对象集合
        sheet.autoSizeColumn(1, true);
        //对象置空
        response.reset();
        response.setContentType("application/ms-excel;charset=UTF-8");
        response.setHeader("Content-Dispostion", "attachment;filename=".concat(String.valueOf(URLEncoder.encode("用户信息模板.xls", "UTF-8"))));
        try {
            workbook.write(response.getOutputStream());
            response.getOutputStream().flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (workbook != null) {
                workbook.close();
            }
            if (response.getOutputStream() != null) {
                response.getOutputStream().close();
            }


        }


    }

    @RequestMapping("/importdata")
    public String importdata(HttpServletRequest request, HttpServletResponse response, MultipartFile file) throws Exception {
        System.out.println("进入导入数据模板");
        String fileName = file.getOriginalFilename();
        List<Warehouselisting> warehouselistingList = new ArrayList<>();
        if (!fileName.matches("^.+\\.(?i)(xls)$") && !fileName.matches("^.+\\.(?i)(xlsx)")) {
            throw new Exception("上传文件格式不正确");
        }
        //2003 xls 2007 xlsx
        boolean isExcel2003 = true;
        if (fileName.matches("^.+\\.(?i)(xlsx)$")) {
            isExcel2003 = false;
        }
        InputStream is = file.getInputStream();
        Workbook wb = null;
        if (isExcel2003) {
            wb = new HSSFWorkbook(is);
        } else {
            wb = new XSSFWorkbook(is);
        }
        Sheet sheet = wb.getSheetAt(0);
        boolean notNull = false;
        if (sheet != null) {
            notNull = true;
        }
        Warehouselisting warehouselisting;
        for (int r = 1; r <= sheet.getLastRowNum(); r++) {
            Row row = sheet.getRow(r);
            if (row == null) {
                continue;
            }
            warehouselisting = new Warehouselisting();
            //单元格类型等于1,表示单元格里面的内容是文本内容
       /*     if (row.getCell(0).getCellType() != 1) {
                throw new Exception("导入失败(第" + (r + 1) + "行,用户名请设为文本格式");
            }*/
            //   row.getCell(2).setCellType(Cell.CELL_TYPE_STRING);//得到每一行第二个单元格的值
            row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
            row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
            String id = row.getCell(0).getStringCellValue();
            String productId = row.getCell(1).getStringCellValue();
            String productName = row.getCell(2).getStringCellValue();//得到每一个第一个单元格的值
            if (productName == null || productName.isEmpty()) {//判断是否为空
                throw new Exception("导入失败(第" + (r + 1) + "行，序号未填写");
            }
            //row.getCell(3).setCellType(Cell.CELL_TYPE_STRING);//得到每一行第二个单元格的值
            String productStandard = row.getCell(3).getStringCellValue();
            if (productStandard == null || productStandard.isEmpty()) {
                throw new Exception("导入失败(第" + (r + 1) + "行,产品编号未填写");
            }
            String category = row.getCell(4).getStringCellValue();
            String storageCell = row.getCell(5).getStringCellValue();
            String warehouse = row.getCell(6).getStringCellValue();
            String storageLocation = row.getCell(7).getStringCellValue();
            warehouselisting.setId(Integer.parseInt(id));
            warehouselisting.setProductId(Integer.parseInt(productId));
            warehouselisting.setProductName(productName);
            warehouselisting.setProductStandard(productStandard);
            warehouselisting.setCategory(category);
            warehouselisting.setStorageCell(storageCell);
            warehouselisting.setWarehouse(warehouse);
            warehouselisting.setStorageLocation(storageLocation);
            warehouselistingService.addWarehouselisting(warehouselisting);
            warehouselistingList.add(warehouselisting);
        }
        for (Warehouselisting warehouselistingdata : warehouselistingList) {
            System.out.println(warehouselistingdata.getProductName());
        }
        return "redirect:/warehouselisting";
    }


}


