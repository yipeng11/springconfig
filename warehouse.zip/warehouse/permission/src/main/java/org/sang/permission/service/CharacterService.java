package org.sang.permission.service;

import java.util.List;

public interface CharacterService {
    List<Character> characterList();

    int addCharacter(Character character);

    int deleteCharacter(int id);

    Character selectCharacter(int id);

    int updateCharacter(Character character);
}
