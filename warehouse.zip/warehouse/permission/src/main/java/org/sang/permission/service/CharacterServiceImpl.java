package org.sang.permission.service;

import org.sang.comment.mapper.CharacterMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CharacterServiceImpl implements CharacterService {
    @Autowired
    CharacterMapper characterMapper;

    @Override
    public List<Character> characterList() {
        return characterMapper.characterList();
    }

    @Override
    public int addCharacter(Character character) {
        return characterMapper.addCharacter(character);
    }

    @Override
    public int deleteCharacter(int id) {
        return characterMapper.deleteCharacter(id);
    }

    @Override
    public Character selectCharacter(int id) {
        return characterMapper.selectCharacter(id);
    }

    @Override
    public int updateCharacter(Character character) {
        return characterMapper.updateCharacter(character);
    }
}
