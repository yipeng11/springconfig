package org.sang.permission.service;

import org.apache.ibatis.annotations.Param;
import org.sang.comment.entity.Permission;

import java.util.List;

public interface PermissionService {
    List<Permission> getAllPermission();

    //资源管理
    List<Permission> getListPermission(Permission permission);

    //权限分配
    List<Permission> getPermission();

    //添加权限
    int addPermission(@Param("menuid") int menuid, @Param("roleid") int roleid);

    int getCount();

    List<Permission> getDelPermission(int roleId);

    int delPermission(int rmId);


}
