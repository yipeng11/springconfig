package myrule;

import com.netflix.loadbalancer.IRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyRules {
    @Bean
    public IRule myRuleRandom(){
        //return new RandomRule();
        //return new RoundRobinRule();
        return new MyRomdomRule();
    }
}
