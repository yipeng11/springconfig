package org.sang.comment.mapper;

import java.util.List;

public interface CharacterMapper {
    List<Character> characterList();

    int addCharacter(Character character);

    int deleteCharacter(int id);

    Character selectCharacter(int id);

    int updateCharacter(Character character);

}
