package org.sang.comment.mapper;


import org.sang.comment.entity.Warehouselisting;

import java.util.List;

public interface WarehouselistingMapper {
    int addWarehouselisting(Warehouselisting warehouselisting);

    List<Warehouselisting> listWarehouselisting();


}
