package org.sang.comment.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.sang.comment.entity.Menu;

import java.util.List;

@Mapper
public interface MenuMapper {
    List<Menu> getAllMenus();
}
