package org.sang.comment.mapper;


import org.sang.comment.entity.Department;

import java.util.List;

public interface DepartMentMapper {
    List<Department> departmentList();

    int addDepartment(Department department);

    int deleteDepartment(int id);

    Department selectDepartment(int id);

    int updateDepartment(Department department);


}
