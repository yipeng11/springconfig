package org.sang.comment.entity;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class User implements UserDetails {
    private int id;//主键ID
    private String username;//用户名
    private String password;//密码
    private String workNum;//工号
    private String name;//真实姓名
    private String phone;//电话号码
    private String fixedlinetelephone;//固定电话
    private int deptNo;//部门编号
    private String deptName;//部门名称
    private String email;//邮箱地址
    private Date createDate;//创建日期
    private int logincount;//登录次数
    private String desc;//描述
    private int isaviliable;//账户是否可用
    private String createUser;//创建者
    private int roleid;//角色id
    private List<Role> roles;
    private int page;//当前页数

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }


    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getRoleid() {
        return roleid;
    }

    public void setRoleid(int roleid) {
        this.roleid = roleid;
    }


    public String getFixedlinetelephone() {
        return fixedlinetelephone;
    }

    public void setFixedlinetelephone(String fixedlinetelephone) {
        this.fixedlinetelephone = fixedlinetelephone;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for (Role role : roles) {
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWorkNum() {
        return workNum;
    }

    public void setWorkNum(String workNum) {
        this.workNum = workNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(int deptNo) {
        this.deptNo = deptNo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getIsaviliable() {
        return isaviliable;
    }

    public void setIsaviliable(int isaviliable) {
        this.isaviliable = isaviliable;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public int getLogincount() {
        return logincount;
    }

    public void setLogincount(int logincount) {
        this.logincount = logincount;
    }


    @Override
    public boolean isAccountNonExpired() {
        if (this.isaviliable == 1) {
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean isAccountNonLocked() {
        if (this.isaviliable == 1) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isCredentialsNonExpired() {
        if (this.isaviliable == 1) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isEnabled() {
        if (this.isaviliable == 1) {
            return true;
        } else {
            return false;
        }
    }
}
