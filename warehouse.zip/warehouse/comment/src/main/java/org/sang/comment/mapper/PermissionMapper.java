package org.sang.comment.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.sang.comment.entity.Permission;

import java.util.List;

@Mapper
public interface PermissionMapper {
    List<Permission> getAllPermission();

    //资源管理
    List<Permission> getListPermission(Permission permission);

    //权限分配
    List<Permission> getPermission();

    //添加权限
    int addPermission(@Param("mid") int menuid, @Param("rid") int rid);

    int getCount();

    List<Permission> getDelPermission(int roleId);

    int delPermission(int rmId);
}
