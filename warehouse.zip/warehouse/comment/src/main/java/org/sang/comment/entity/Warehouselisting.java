package org.sang.comment.entity;

public class Warehouselisting {
    private int id;//序号
    private int productId;//产品编号
    private String productName;//产品名称
    private String productStandard;//产品规格
    private String category;//类别
    private String storageCell;//储存单位
    private String warehouse;//仓库
    private String storageLocation;//库位

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductStandard() {
        return productStandard;
    }

    public void setProductStandard(String productStandard) {
        this.productStandard = productStandard;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStorageCell() {
        return storageCell;
    }

    public void setStorageCell(String storageCell) {
        this.storageCell = storageCell;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getStorageLocation() {
        return storageLocation;
    }

    public void setStorageLocation(String storageLocation) {
        this.storageLocation = storageLocation;
    }


}
